// 332-f0503033c70cb4c8.js
'use strict';
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
	[332],
	{
		43789: function (a, b, c) {
			c.d(b, {
				o: function () {
					return d;
				},
			});
			var d = (0, c(78928).sj)({provider: void 0, status: 'idle'});
		},
		27275: function (a, b, c) {
			c.d(b, {
				YY: function () {
					return z;
				},
				Dr: function () {
					return F;
				},
				_6: function () {
					return J;
				},
				ww: function () {
					return v;
				},
				pH: function () {
					return w;
				},
				W: function () {
					return x;
				},
				LK: function () {
					return D;
				},
				JP: function () {
					return t;
				},
				zy: function () {
					return u;
				},
				HV: function () {
					return B;
				},
				XW: function () {
					return H;
				},
			});
			var d = c(29452),
				e = c(36026),
				f = c(64723),
				g = c.n(f),
				h = c(89751),
				i = c(35668),
				j = c(65548),
				k = c(40845),
				l = c.n(k),
				m = c(78928),
				n =
					'\n[\n	{\n		"anonymous": false,\n		"inputs": [\n			{\n				"indexed": true,\n				"internalType": "address",\n				"name": "user",\n				"type": "address"\n			},\n			{\n				"indexed": true,\n				"internalType": "uint256",\n				"name": "pid",\n				"type": "uint256"\n			},\n			{\n				"indexed": false,\n				"internalType": "uint256",\n				"name": "amount",\n				"type": "uint256"\n			}\n		],\n		"name": "Deposit",\n		"type": "event"\n	},\n	{\n		"anonymous": false,\n		"inputs": [\n			{\n				"indexed": true,\n				"internalType": "uint256",\n				"name": "pid",\n				"type": "uint256"\n			},\n			{\n				"indexed": false,\n				"internalType": "uint256",\n				"name": "allocPoint",\n				"type": "uint256"\n			},\n			{\n				"indexed": true,\n				"internalType": "contract IERC20",\n				"name": "lpToken",\n				"type": "address"\n			}\n		],\n		"name": "LogPoolAddition",\n		"type": "event"\n	},\n	{\n		"anonymous": false,\n		"inputs": [\n			{\n				"indexed": false,\n				"internalType": "uint256",\n				"name": "amount",\n				"type": "uint256"\n			}\n		],\n		"name": "LogRewardPerBlock",\n		"type": "event"\n	},\n	{\n		"anonymous": false,\n		"inputs": [\n			{\n				"indexed": true,\n				"internalType": "uint256",\n				"name": "pid",\n				"type": "uint256"\n			},\n			{\n				"indexed": false,\n				"internalType": "uint256",\n				"name": "lockDuration",\n				"type": "uint256"\n			}\n		],\n		"name": "LogSetLockDuration",\n		"type": "event"\n	},\n	{\n		"anonymous": false,\n		"inputs": [\n			{\n				"indexed": true,\n				"internalType": "uint256",\n				"name": "pid",\n				"type": "uint256"\n			},\n			{\n				"indexed": false,\n				"internalType": "uint256",\n				"name": "allocPoint",\n				"type": "uint256"\n			}\n		],\n		"name": "LogSetPool",\n		"type": "event"\n	},\n	{\n		"anonymous": false,\n		"inputs": [\n			{\n				"indexed": true,\n				"internalType": "uint256",\n				"name": "pid",\n				"type": "uint256"\n			},\n			{\n				"indexed": false,\n				"internalType": "uint256",\n				"name": "lastRewardBlock",\n				"type": "uint256"\n			},\n			{\n				"indexed": false,\n				"internalType": "uint256",\n				"name": "lpSupply",\n				"type": "uint256"\n			},\n			{\n				"indexed": false,\n				"internalType": "uint256",\n				"name": "accRewardPerShare",\n				"type": "uint256"\n			}\n		],\n		"name": "LogUpdatePool",\n		"type": "event"\n	},\n	{\n		"anonymous": false,\n		"inputs": [\n			{\n				"indexed": true,\n				"internalType": "address",\n				"name": "previousOwner",\n				"type": "address"\n			},\n			{\n				"indexed": true,\n				"internalType": "address",\n				"name": "newOwner",\n				"type": "address"\n			}\n		],\n		"name": "OwnershipTransferred",\n		"type": "event"\n	},\n	{\n		"anonymous": false,\n		"inputs": [\n			{\n				"indexed": true,\n				"internalType": "address",\n				"name": "user",\n				"type": "address"\n			},\n			{\n				"indexed": true,\n				"internalType": "uint256",\n				"name": "pid",\n				"type": "uint256"\n			},\n			{\n				"indexed": false,\n				"internalType": "uint256",\n				"name": "amount",\n				"type": "uint256"\n			}\n		],\n		"name": "RewardPaid",\n		"type": "event"\n	},\n	{\n		"anonymous": false,\n		"inputs": [\n			{\n				"indexed": true,\n				"internalType": "address",\n				"name": "user",\n				"type": "address"\n			},\n			{\n				"indexed": true,\n				"internalType": "uint256",\n				"name": "pid",\n				"type": "uint256"\n			},\n			{\n				"indexed": false,\n				"internalType": "uint256",\n				"name": "amount",\n				"type": "uint256"\n			}\n		],\n		"name": "Withdraw",\n		"type": "event"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "uint256",\n				"name": "_allocPoint",\n				"type": "uint256"\n			},\n			{\n				"internalType": "contract IERC20",\n				"name": "_lpToken",\n				"type": "address"\n			},\n			{\n				"internalType": "bool",\n				"name": "_withUpdate",\n				"type": "bool"\n			}\n		],\n		"name": "add",\n		"outputs": [],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "uint256",\n				"name": "_pid",\n				"type": "uint256"\n			},\n			{\n				"internalType": "address",\n				"name": "_account",\n				"type": "address"\n			}\n		],\n		"name": "claim",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "uint256",\n				"name": "_amountTokenDesired",\n				"type": "uint256"\n			},\n			{\n				"internalType": "uint256",\n				"name": "_amountTokenMin",\n				"type": "uint256"\n			},\n			{\n				"internalType": "uint256",\n				"name": "_amountETHMin",\n				"type": "uint256"\n			}\n		],\n		"name": "compoundBig",\n		"outputs": [],\n		"stateMutability": "payable",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "compoundSmol",\n		"outputs": [],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "uint256",\n				"name": "_pid",\n				"type": "uint256"\n			},\n			{\n				"internalType": "uint256",\n				"name": "_amount",\n				"type": "uint256"\n			},\n			{\n				"internalType": "address",\n				"name": "_account",\n				"type": "address"\n			}\n		],\n		"name": "deposit",\n		"outputs": [],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "massUpdatePools",\n		"outputs": [],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "renounceOwnership",\n		"outputs": [],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "uint256",\n				"name": "_pid",\n				"type": "uint256"\n			},\n			{\n				"internalType": "uint256",\n				"name": "_allocPoint",\n				"type": "uint256"\n			},\n			{\n				"internalType": "bool",\n				"name": "_withUpdate",\n				"type": "bool"\n			}\n		],\n		"name": "set",\n		"outputs": [],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "uint256",\n				"name": "_pid",\n				"type": "uint256"\n			},\n			{\n				"internalType": "uint256",\n				"name": "_lockDuration",\n				"type": "uint256"\n			}\n		],\n		"name": "setLockDuration",\n		"outputs": [],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "address",\n				"name": "newOwner",\n				"type": "address"\n			}\n		],\n		"name": "transferOwnership",\n		"outputs": [],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "uint256",\n				"name": "_pid",\n				"type": "uint256"\n			}\n		],\n		"name": "updatePool",\n		"outputs": [],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "uint256",\n				"name": "_rewardPerBlock",\n				"type": "uint256"\n			}\n		],\n		"name": "updateRewardPerBlock",\n		"outputs": [],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "uint256",\n				"name": "_pid",\n				"type": "uint256"\n			},\n			{\n				"internalType": "uint256",\n				"name": "_amount",\n				"type": "uint256"\n			}\n		],\n		"name": "withdraw",\n		"outputs": [],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "contract IEggsToken",\n				"name": "_eggs",\n				"type": "address"\n			},\n			{\n				"internalType": "contract IUniswapPair",\n				"name": "_eggsLp",\n				"type": "address"\n			},\n			{\n				"internalType": "contract IUniswapV2Router",\n				"name": "_router",\n				"type": "address"\n			},\n			{\n				"internalType": "uint256",\n				"name": "_rewardPerBlock",\n				"type": "uint256"\n			},\n			{\n				"internalType": "uint256",\n				"name": "_startBlock",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "nonpayable",\n		"type": "constructor"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "uint256",\n				"name": "principal",\n				"type": "uint256"\n			},\n			{\n				"internalType": "uint256",\n				"name": "ratio",\n				"type": "uint256"\n			},\n			{\n				"internalType": "uint256",\n				"name": "n",\n				"type": "uint256"\n			}\n		],\n		"name": "compound",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "pure",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "compoundRatio",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "eggs",\n		"outputs": [\n			{\n				"internalType": "contract IEggsToken",\n				"name": "",\n				"type": "address"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "eggsLp",\n		"outputs": [\n			{\n				"internalType": "contract IUniswapPair",\n				"name": "",\n				"type": "address"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "lastBlock",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"name": "lockDurations",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "owner",\n		"outputs": [\n			{\n				"internalType": "address",\n				"name": "",\n				"type": "address"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "uint256",\n				"name": "_pid",\n				"type": "uint256"\n			},\n			{\n				"internalType": "address",\n				"name": "_user",\n				"type": "address"\n			}\n		],\n		"name": "pendingReward",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"name": "poolInfo",\n		"outputs": [\n			{\n				"internalType": "contract IERC20",\n				"name": "lpToken",\n				"type": "address"\n			},\n			{\n				"internalType": "uint256",\n				"name": "allocPoint",\n				"type": "uint256"\n			},\n			{\n				"internalType": "uint256",\n				"name": "lastRewardBlock",\n				"type": "uint256"\n			},\n			{\n				"internalType": "uint256",\n				"name": "accRewardPerShare",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "poolLength",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "int128",\n				"name": "x",\n				"type": "int128"\n			},\n			{\n				"internalType": "uint256",\n				"name": "n",\n				"type": "uint256"\n			}\n		],\n		"name": "pow",\n		"outputs": [\n			{\n				"internalType": "int128",\n				"name": "r",\n				"type": "int128"\n			}\n		],\n		"stateMutability": "pure",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "rewardPerBlock",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "router",\n		"outputs": [\n			{\n				"internalType": "contract IUniswapV2Router",\n				"name": "",\n				"type": "address"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "startBlock",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "totalAllocPoint",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			},\n			{\n				"internalType": "address",\n				"name": "",\n				"type": "address"\n			}\n		],\n		"name": "userInfo",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "amount",\n				"type": "uint256"\n			},\n			{\n				"internalType": "uint256",\n				"name": "rewardDebt",\n				"type": "uint256"\n			},\n			{\n				"internalType": "uint256",\n				"name": "lockEndedTimestamp",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	}\n]\n',
				o =
					'\n[\n	{\n		"anonymous": false,\n		"inputs": [\n			{\n				"indexed": true,\n				"internalType": "address",\n				"name": "user",\n				"type": "address"\n			},\n			{\n				"indexed": false,\n				"internalType": "uint256",\n				"name": "amount",\n				"type": "uint256"\n			}\n		],\n		"name": "Deposit",\n		"type": "event"\n	},\n	{\n		"anonymous": false,\n		"inputs": [\n			{\n				"indexed": false,\n				"internalType": "uint256",\n				"name": "lockDuration",\n				"type": "uint256"\n			}\n		],\n		"name": "LogSetLockDuration",\n		"type": "event"\n	},\n	{\n		"anonymous": false,\n		"inputs": [\n			{\n				"indexed": true,\n				"internalType": "address",\n				"name": "previousOwner",\n				"type": "address"\n			},\n			{\n				"indexed": true,\n				"internalType": "address",\n				"name": "newOwner",\n				"type": "address"\n			}\n		],\n		"name": "OwnershipTransferred",\n		"type": "event"\n	},\n	{\n		"anonymous": false,\n		"inputs": [\n			{\n				"indexed": true,\n				"internalType": "address",\n				"name": "user",\n				"type": "address"\n			},\n			{\n				"indexed": false,\n				"internalType": "uint256",\n				"name": "amount",\n				"type": "uint256"\n			}\n		],\n		"name": "Withdraw",\n		"type": "event"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "uint256",\n				"name": "_amount",\n				"type": "uint256"\n			}\n		],\n		"name": "deposit",\n		"outputs": [],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "renounceOwnership",\n		"outputs": [],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "uint256",\n				"name": "_lockDuration",\n				"type": "uint256"\n			}\n		],\n		"name": "setLockDuration",\n		"outputs": [],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "address",\n				"name": "newOwner",\n				"type": "address"\n			}\n		],\n		"name": "transferOwnership",\n		"outputs": [],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "uint256",\n				"name": "_amount",\n				"type": "uint256"\n			}\n		],\n		"name": "withdraw",\n		"outputs": [],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "contract IEggsToken",\n				"name": "_eggs",\n				"type": "address"\n			},\n			{\n				"internalType": "uint256",\n				"name": "_lockDuration",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "nonpayable",\n		"type": "constructor"\n	},\n	{\n		"inputs": [],\n		"name": "eggs",\n		"outputs": [\n			{\n				"internalType": "contract IEggsToken",\n				"name": "",\n				"type": "address"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "lockDuration",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "owner",\n		"outputs": [\n			{\n				"internalType": "address",\n				"name": "",\n				"type": "address"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "totalStaked",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "address",\n				"name": "",\n				"type": "address"\n			}\n		],\n		"name": "userInfo",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "amount",\n				"type": "uint256"\n			},\n			{\n				"internalType": "uint256",\n				"name": "lockEndedTimestamp",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	}\n]\n',
				p = c(5926),
				q = c(68714),
				r = c(43789),
				s = c(21782),
				t = (0, m.sj)([
					{
						type: 'fullprotec',
						id: 100,
						label: 'FULL protec \uD83E\uDD5A\uD83D\uDEE1️',
						stakingToken: q.XC.eggs,
						rewardToken: q.XC.eggs,
						lpInfo: q.XC.eggs,
						lpUrl: 'https://app.uniswap.com/#/add/v2/ETH/'.concat(
							q.XC.eggs.address,
						),
					},
					{
						type: 'staking',
						id: 0,
						label: q.XC.eggsLp.label,
						stakingToken: q.XC.eggsLp,
						rewardToken: q.XC.eggs,
						lpInfo: q.XC.eggsLp,
						lpUrl: 'https://app.uniswap.com/#/add/v2/ETH/'.concat(
							q.XC.eggs.address,
						),
					},
					{
						type: 'staking',
						id: 1,
						label: q.XC.eggs.label,
						stakingToken: q.XC.eggs,
						rewardToken: q.XC.eggs,
						lpInfo: q.XC.eggs,
						lpUrl: 'https://app.uniswap.com/#/add/v2/ETH/'.concat(
							q.XC.eggs.address,
						),
					},
				]),
				u = (0, m.sj)({
					totalTvl: '',
					eggsCircSupply: 0,
					eggsCircSupplyFormatted: '',
					eggsMarketcap: '',
					eggsTotalLiquidity: '',
					eggsInFarm: 0,
					eggsInFarmFormatted: '',
					eggsTotalSupply: 0,
					eggsTotalSupplyFormatted: '',
					eggsFDV: '',
					eggsLpApr: 0,
				}),
				v = '0x26f50a09fb6c7b4917f07947dab59be5d5064c22',
				w = '0x98d9F08824798D7FD37BD0DD740069Baf31C37e7';
			function x(a) {
				return y.apply(this, arguments);
			}
			function y() {
				return (y = (0, d.Z)(
					g().mark(function a(b) {
						var c;
						return g().wrap(function (a) {
							for (;;)
								switch ((a.prev = a.next)) {
									case 0:
										(c = function () {
											t.forEach(
												(function () {
													var a = (0, d.Z)(
														g().mark(function a(c) {
															var d,
																f,
																k,
																m,
																x,
																y,
																z,
																A,
																B,
																C,
																D,
																E,
																F,
																G,
																H,
																I,
																J,
																K,
																L,
																M,
																N;
															return g().wrap(
																function (a) {
																	for (;;)
																		switch ((a.prev = a.next)) {
																			case 0:
																				return (
																					(a.prev = 0),
																					(d = new i.Contract(
																						c.stakingToken.address,
																						h.em,
																						b,
																					)),
																					(f = new i.Contract(v, n, b)),
																					(k = new i.Contract(w, o, b)),
																					(m = new i.Contract(
																						q.XC.eggs.address,
																						'\n[\n	{\n		"inputs": [],\n		"stateMutability": "nonpayable",\n		"type": "constructor"\n	},\n	{\n		"anonymous": false,\n		"inputs": [\n			{\n				"indexed": true,\n				"internalType": "address",\n				"name": "owner",\n				"type": "address"\n			},\n			{\n				"indexed": true,\n				"internalType": "address",\n				"name": "spender",\n				"type": "address"\n			},\n			{\n				"indexed": false,\n				"internalType": "uint256",\n				"name": "value",\n				"type": "uint256"\n			}\n		],\n		"name": "Approval",\n		"type": "event"\n	},\n	{\n		"anonymous": false,\n		"inputs": [\n			{\n				"indexed": false,\n				"internalType": "address",\n				"name": "from",\n				"type": "address"\n			},\n			{\n				"indexed": false,\n				"internalType": "uint256",\n				"name": "amount",\n				"type": "uint256"\n			}\n		],\n		"name": "Burn",\n		"type": "event"\n	},\n	{\n		"anonymous": false,\n		"inputs": [\n			{\n				"indexed": false,\n				"internalType": "address",\n				"name": "to",\n				"type": "address"\n			},\n			{\n				"indexed": false,\n				"internalType": "uint256",\n				"name": "amount",\n				"type": "uint256"\n			}\n		],\n		"name": "Mint",\n		"type": "event"\n	},\n	{\n		"anonymous": false,\n		"inputs": [\n			{\n				"indexed": true,\n				"internalType": "address",\n				"name": "previousOwner",\n				"type": "address"\n			},\n			{\n				"indexed": true,\n				"internalType": "address",\n				"name": "newOwner",\n				"type": "address"\n			}\n		],\n		"name": "OwnershipTransferred",\n		"type": "event"\n	},\n	{\n		"anonymous": false,\n		"inputs": [\n			{\n				"indexed": false,\n				"internalType": "uint256",\n				"name": "epoch",\n				"type": "uint256"\n			},\n			{\n				"indexed": false,\n				"internalType": "uint256",\n				"name": "prevEggssScalingFactor",\n				"type": "uint256"\n			},\n			{\n				"indexed": false,\n				"internalType": "uint256",\n				"name": "newEggssScalingFactor",\n				"type": "uint256"\n			}\n		],\n		"name": "Rebase",\n		"type": "event"\n	},\n	{\n		"anonymous": false,\n		"inputs": [\n			{\n				"indexed": true,\n				"internalType": "bytes32",\n				"name": "role",\n				"type": "bytes32"\n			},\n			{\n				"indexed": true,\n				"internalType": "bytes32",\n				"name": "previousAdminRole",\n				"type": "bytes32"\n			},\n			{\n				"indexed": true,\n				"internalType": "bytes32",\n				"name": "newAdminRole",\n				"type": "bytes32"\n			}\n		],\n		"name": "RoleAdminChanged",\n		"type": "event"\n	},\n	{\n		"anonymous": false,\n		"inputs": [\n			{\n				"indexed": true,\n				"internalType": "bytes32",\n				"name": "role",\n				"type": "bytes32"\n			},\n			{\n				"indexed": true,\n				"internalType": "address",\n				"name": "account",\n				"type": "address"\n			},\n			{\n				"indexed": true,\n				"internalType": "address",\n				"name": "sender",\n				"type": "address"\n			}\n		],\n		"name": "RoleGranted",\n		"type": "event"\n	},\n	{\n		"anonymous": false,\n		"inputs": [\n			{\n				"indexed": true,\n				"internalType": "bytes32",\n				"name": "role",\n				"type": "bytes32"\n			},\n			{\n				"indexed": true,\n				"internalType": "address",\n				"name": "account",\n				"type": "address"\n			},\n			{\n				"indexed": true,\n				"internalType": "address",\n				"name": "sender",\n				"type": "address"\n			}\n		],\n		"name": "RoleRevoked",\n		"type": "event"\n	},\n	{\n		"anonymous": false,\n		"inputs": [\n			{\n				"indexed": true,\n				"internalType": "address",\n				"name": "from",\n				"type": "address"\n			},\n			{\n				"indexed": true,\n				"internalType": "address",\n				"name": "to",\n				"type": "address"\n			},\n			{\n				"indexed": false,\n				"internalType": "uint256",\n				"name": "value",\n				"type": "uint256"\n			}\n		],\n		"name": "Transfer",\n		"type": "event"\n	},\n	{\n		"inputs": [],\n		"name": "BASE",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "DEFAULT_ADMIN_ROLE",\n		"outputs": [\n			{\n				"internalType": "bytes32",\n				"name": "",\n				"type": "bytes32"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "DOMAIN_SEPARATOR",\n		"outputs": [\n			{\n				"internalType": "bytes32",\n				"name": "",\n				"type": "bytes32"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "DOMAIN_TYPEHASH",\n		"outputs": [\n			{\n				"internalType": "bytes32",\n				"name": "",\n				"type": "bytes32"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "MINTER_ROLE",\n		"outputs": [\n			{\n				"internalType": "bytes32",\n				"name": "",\n				"type": "bytes32"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "PERMIT_TYPEHASH",\n		"outputs": [\n			{\n				"internalType": "bytes32",\n				"name": "",\n				"type": "bytes32"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "REBASER_ROLE",\n		"outputs": [\n			{\n				"internalType": "bytes32",\n				"name": "",\n				"type": "bytes32"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "address",\n				"name": "owner_",\n				"type": "address"\n			},\n			{\n				"internalType": "address",\n				"name": "spender",\n				"type": "address"\n			}\n		],\n		"name": "allowance",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "address",\n				"name": "spender",\n				"type": "address"\n			},\n			{\n				"internalType": "uint256",\n				"name": "value",\n				"type": "uint256"\n			}\n		],\n		"name": "approve",\n		"outputs": [\n			{\n				"internalType": "bool",\n				"name": "",\n				"type": "bool"\n			}\n		],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "address",\n				"name": "who",\n				"type": "address"\n			}\n		],\n		"name": "balanceOf",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "address",\n				"name": "who",\n				"type": "address"\n			}\n		],\n		"name": "balanceOfUnderlying",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "uint256",\n				"name": "amount",\n				"type": "uint256"\n			}\n		],\n		"name": "burn",\n		"outputs": [],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "address",\n				"name": "account",\n				"type": "address"\n			},\n			{\n				"internalType": "uint256",\n				"name": "amount",\n				"type": "uint256"\n			}\n		],\n		"name": "burnFrom",\n		"outputs": [],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "decimals",\n		"outputs": [\n			{\n				"internalType": "uint8",\n				"name": "",\n				"type": "uint8"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "address",\n				"name": "spender",\n				"type": "address"\n			},\n			{\n				"internalType": "uint256",\n				"name": "subtractedValue",\n				"type": "uint256"\n			}\n		],\n		"name": "decreaseAllowance",\n		"outputs": [\n			{\n				"internalType": "bool",\n				"name": "",\n				"type": "bool"\n			}\n		],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "uint256",\n				"name": "eggs",\n				"type": "uint256"\n			}\n		],\n		"name": "eggsToFragment",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "eggssScalingFactor",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "uint256",\n				"name": "value",\n				"type": "uint256"\n			}\n		],\n		"name": "fragmentToEggs",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "bytes32",\n				"name": "role",\n				"type": "bytes32"\n			}\n		],\n		"name": "getRoleAdmin",\n		"outputs": [\n			{\n				"internalType": "bytes32",\n				"name": "",\n				"type": "bytes32"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "bytes32",\n				"name": "role",\n				"type": "bytes32"\n			},\n			{\n				"internalType": "uint256",\n				"name": "index",\n				"type": "uint256"\n			}\n		],\n		"name": "getRoleMember",\n		"outputs": [\n			{\n				"internalType": "address",\n				"name": "",\n				"type": "address"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "bytes32",\n				"name": "role",\n				"type": "bytes32"\n			}\n		],\n		"name": "getRoleMemberCount",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "bytes32",\n				"name": "role",\n				"type": "bytes32"\n			},\n			{\n				"internalType": "address",\n				"name": "account",\n				"type": "address"\n			}\n		],\n		"name": "grantRole",\n		"outputs": [],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "bytes32",\n				"name": "role",\n				"type": "bytes32"\n			},\n			{\n				"internalType": "address",\n				"name": "account",\n				"type": "address"\n			}\n		],\n		"name": "hasRole",\n		"outputs": [\n			{\n				"internalType": "bool",\n				"name": "",\n				"type": "bool"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "address",\n				"name": "spender",\n				"type": "address"\n			},\n			{\n				"internalType": "uint256",\n				"name": "addedValue",\n				"type": "uint256"\n			}\n		],\n		"name": "increaseAllowance",\n		"outputs": [\n			{\n				"internalType": "bool",\n				"name": "",\n				"type": "bool"\n			}\n		],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "initSupply",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "internalDecimals",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "maxScalingFactor",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "address",\n				"name": "to",\n				"type": "address"\n			},\n			{\n				"internalType": "uint256",\n				"name": "amount",\n				"type": "uint256"\n			}\n		],\n		"name": "mint",\n		"outputs": [\n			{\n				"internalType": "bool",\n				"name": "",\n				"type": "bool"\n			}\n		],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "address",\n				"name": "to",\n				"type": "address"\n			},\n			{\n				"internalType": "uint256",\n				"name": "amount",\n				"type": "uint256"\n			}\n		],\n		"name": "mintUnderlying",\n		"outputs": [\n			{\n				"internalType": "bool",\n				"name": "",\n				"type": "bool"\n			}\n		],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "name",\n		"outputs": [\n			{\n				"internalType": "string",\n				"name": "",\n				"type": "string"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "address",\n				"name": "",\n				"type": "address"\n			}\n		],\n		"name": "nonces",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "owner",\n		"outputs": [\n			{\n				"internalType": "address",\n				"name": "",\n				"type": "address"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "address",\n				"name": "owner",\n				"type": "address"\n			},\n			{\n				"internalType": "address",\n				"name": "spender",\n				"type": "address"\n			},\n			{\n				"internalType": "uint256",\n				"name": "value",\n				"type": "uint256"\n			},\n			{\n				"internalType": "uint256",\n				"name": "deadline",\n				"type": "uint256"\n			},\n			{\n				"internalType": "uint8",\n				"name": "v",\n				"type": "uint8"\n			},\n			{\n				"internalType": "bytes32",\n				"name": "r",\n				"type": "bytes32"\n			},\n			{\n				"internalType": "bytes32",\n				"name": "s",\n				"type": "bytes32"\n			}\n		],\n		"name": "permit",\n		"outputs": [],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "uint256",\n				"name": "epoch",\n				"type": "uint256"\n			},\n			{\n				"internalType": "uint256",\n				"name": "indexDelta",\n				"type": "uint256"\n			},\n			{\n				"internalType": "bool",\n				"name": "positive",\n				"type": "bool"\n			}\n		],\n		"name": "rebase",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "renounceOwnership",\n		"outputs": [],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "bytes32",\n				"name": "role",\n				"type": "bytes32"\n			},\n			{\n				"internalType": "address",\n				"name": "account",\n				"type": "address"\n			}\n		],\n		"name": "renounceRole",\n		"outputs": [],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "address",\n				"name": "token",\n				"type": "address"\n			},\n			{\n				"internalType": "address",\n				"name": "to",\n				"type": "address"\n			},\n			{\n				"internalType": "uint256",\n				"name": "amount",\n				"type": "uint256"\n			}\n		],\n		"name": "rescueTokens",\n		"outputs": [\n			{\n				"internalType": "bool",\n				"name": "",\n				"type": "bool"\n			}\n		],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "bytes32",\n				"name": "role",\n				"type": "bytes32"\n			},\n			{\n				"internalType": "address",\n				"name": "account",\n				"type": "address"\n			}\n		],\n		"name": "revokeRole",\n		"outputs": [],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "bytes4",\n				"name": "interfaceId",\n				"type": "bytes4"\n			}\n		],\n		"name": "supportsInterface",\n		"outputs": [\n			{\n				"internalType": "bool",\n				"name": "",\n				"type": "bool"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "symbol",\n		"outputs": [\n			{\n				"internalType": "string",\n				"name": "",\n				"type": "string"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [],\n		"name": "totalSupply",\n		"outputs": [\n			{\n				"internalType": "uint256",\n				"name": "",\n				"type": "uint256"\n			}\n		],\n		"stateMutability": "view",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "address",\n				"name": "to",\n				"type": "address"\n			},\n			{\n				"internalType": "uint256",\n				"name": "value",\n				"type": "uint256"\n			}\n		],\n		"name": "transfer",\n		"outputs": [\n			{\n				"internalType": "bool",\n				"name": "",\n				"type": "bool"\n			}\n		],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "address",\n				"name": "from",\n				"type": "address"\n			},\n			{\n				"internalType": "address",\n				"name": "to",\n				"type": "address"\n			},\n			{\n				"internalType": "uint256",\n				"name": "value",\n				"type": "uint256"\n			}\n		],\n		"name": "transferFrom",\n		"outputs": [\n			{\n				"internalType": "bool",\n				"name": "",\n				"type": "bool"\n			}\n		],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "address",\n				"name": "newOwner",\n				"type": "address"\n			}\n		],\n		"name": "transferOwnership",\n		"outputs": [],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	},\n	{\n		"inputs": [\n			{\n				"internalType": "address",\n				"name": "to",\n				"type": "address"\n			},\n			{\n				"internalType": "uint256",\n				"name": "value",\n				"type": "uint256"\n			}\n		],\n		"name": "transferUnderlying",\n		"outputs": [\n			{\n				"internalType": "bool",\n				"name": "",\n				"type": "bool"\n			}\n		],\n		"stateMutability": "nonpayable",\n		"type": "function"\n	}\n]\n',
																						b,
																					)),
																					(a.t0 = e.Z),
																					(a.t1 = Promise),
																					(a.next = 9),
																					d.balanceOf(v)
																				);
																			case 9:
																				return (
																					(a.t2 = a.sent),
																					(a.next = 12),
																					m.totalSupply()
																				);
																			case 12:
																				return (
																					(a.t3 = a.sent),
																					(a.next = 15),
																					m.balanceOf(v)
																				);
																			case 15:
																				return (
																					(a.t4 = a.sent),
																					(a.next = 18),
																					m.balanceOf(q.XC.eggsLp.address)
																				);
																			case 18:
																				return (
																					(a.t5 = a.sent),
																					(a.next = 21),
																					k.totalStaked()
																				);
																			case 21:
																				return (
																					(a.t6 = a.sent),
																					(a.t7 = [
																						a.t2,
																						a.t3,
																						a.t4,
																						a.t5,
																						a.t6,
																					]),
																					(a.next = 25),
																					a.t1.all.call(a.t1, a.t7)
																				);
																			case 25:
																				if (
																					((a.t8 = a.sent),
																					(y = (x = (0, a.t0)(a.t8, 5))[0]),
																					(z = x[1]),
																					(A = x[2]),
																					(B = x[3]),
																					(C = x[4]),
																					!(
																						!c.stakingToken.price || y.isZero()
																					))
																				) {
																					a.next = 34;
																					break;
																				}
																				return a.abrupt('return');
																			case 34:
																				if (
																					((D = A.add(B).add(C)),
																					(u.eggsInFarm = Number(
																						(0, j.formatEther)(D),
																					)),
																					(u.eggsInFarmFormatted = (0,
																					s.commify)(
																						Number(
																							(0, j.formatEther)(D),
																						).toFixed(0),
																					)),
																					(u.eggsTotalSupply = Number(
																						(0, j.formatEther)(z.add(C)),
																					)),
																					(u.eggsTotalSupplyFormatted = (0,
																					s.commify)(
																						Number(
																							(0, j.formatEther)(z.add(C)),
																						).toFixed(0),
																					)),
																					(u.eggsCircSupply = Number(
																						(0, j.formatEther)(z.add(C).sub(D)),
																					)),
																					(u.eggsCircSupplyFormatted = (0,
																					s.commify)(
																						Number(
																							(0, j.formatEther)(
																								z.add(C).sub(D),
																							),
																						).toFixed(0),
																					)),
																					(c.tvl = new (l())(
																						(0, j.formatEther)(y),
																					)
																						.multiply(
																							new (l())(c.stakingToken.price),
																						)
																						.getValue()),
																					(c.tvlFormatted = (0, p.W)(
																						Number(c.tvl),
																					)),
																					'fullprotec' === c.type &&
																						((c.tvl = new (l())(
																							(0, j.formatEther)(C),
																						)
																							.multiply(
																								new (l())(c.stakingToken.price),
																							)
																							.getValue()),
																						(c.tvlFormatted = (0, p.W)(
																							Number(c.tvl),
																						))),
																					(E = [900, 100]),
																					(c.apr = new (l())(
																						(10 * E[c.id] * 1e6) / 1e3,
																					)
																						.multiply(new (l())(2628e3))
																						.multiply(
																							new (l())(c.rewardToken.price),
																						)
																						.divide(new (l())(c.tvl), 10)
																						.multiply(new (l())(100))
																						.getValue()),
																					0 === c.id &&
																						(c.apr = new (l())(
																							(10 * E[c.id] * 1e6) / 1e3,
																						)
																							.multiply(new (l())(2628e3))
																							.multiply(
																								new (l())(c.rewardToken.price),
																							)
																							.divide(new (l())(c.tvl), 10)
																							.multiply(new (l())(100))
																							.add(new (l())(u.eggsLpApr))
																							.getValue()),
																					(c.aprFormatted = (0, p.W)(
																						Number(c.apr),
																					)),
																					(u.totalTvl = (0, p.W)(
																						Number(
																							t
																								.map(function (a) {
																									return a.tvl;
																								})
																								.reduce(function (a, b) {
																									return new (l())(b)
																										.add(new (l())(a))
																										.getValue();
																								}),
																						),
																					)),
																					!(F = r.o.account))
																				) {
																					a.next = 87;
																					break;
																				}
																				if ('fullprotec' !== c.type) {
																					a.next = 65;
																					break;
																				}
																				return (a.next = 54), k.userInfo(F);
																			case 54:
																				(H = (G = a.sent).amount),
																					(c.lockEndedTimestamp = Number(
																						G.lockEndedTimestamp.toString(),
																					)),
																					(c.withdrawLocked =
																						new Date().getTime() / 1e3 <=
																						c.lockEndedTimestamp),
																					(I = H),
																					(c.userStakedAmount = (0,
																					j.formatEther)(H)),
																					(c.userStakedAmountFormatted = (0,
																					s.commify)((0, j.formatEther)(H))),
																					(c.userStakedAmountUsd = Number(
																						new (l())((0, j.formatEther)(I))
																							.multiply(
																								new (l())(c.stakingToken.price),
																							)
																							.getValue(),
																					)),
																					(c.userStakedAmountUsdFormatted = (0,
																					p.W)(
																						Number(
																							new (l())((0, j.formatEther)(I))
																								.multiply(
																									new (l())(
																										c.stakingToken.price,
																									),
																								)
																								.getValue(),
																						),
																					)),
																					(a.next = 87);
																				break;
																			case 65:
																				return (
																					(a.t9 = e.Z),
																					(a.next = 68),
																					Promise.all([
																						f.userInfo(c.id, F),
																						f.pendingReward(c.id, F),
																					])
																				);
																			case 68:
																				if (
																					((a.t10 = a.sent),
																					(K = (J = (0, a.t9)(a.t10, 2))[0]),
																					(L = J[1]),
																					(M = K.amount),
																					(c.lockEndedTimestamp = Number(
																						K.lockEndedTimestamp.toString(),
																					)),
																					(c.withdrawLocked =
																						new Date().getTime() / 1e3 <=
																						c.lockEndedTimestamp),
																					(c.userEarned = Number(
																						(0, j.formatEther)(L),
																					)),
																					(c.userEarnedFormatted = (0, p.W)(
																						c.userEarned,
																						3,
																						3,
																					)),
																					(c.userEarnedUsd = (0, p.W)(
																						Number(
																							new (l())((0, j.formatEther)(L))
																								.multiply(
																									new (l())(q.XC.eggs.price),
																								)
																								.getValue(),
																						),
																					)),
																					(N = M),
																					!(
																						'fullprotec' !== c.type &&
																						c.lpInfo.address ===
																							q.XC.eggs.address
																					))
																				) {
																					a.next = 83;
																					break;
																				}
																				return (
																					(a.next = 82), m.eggsToFragment(M)
																				);
																			case 82:
																				N = a.sent;
																			case 83:
																				(c.userStakedAmount = (0,
																				j.formatEther)(M)),
																					(c.userStakedAmountFormatted = (0,
																					s.commify)((0, j.formatEther)(M))),
																					(c.userStakedAmountUsd = Number(
																						new (l())((0, j.formatEther)(N))
																							.multiply(
																								new (l())(c.stakingToken.price),
																							)
																							.getValue(),
																					)),
																					(c.userStakedAmountUsdFormatted = (0,
																					p.W)(
																						Number(
																							new (l())((0, j.formatEther)(N))
																								.multiply(
																									new (l())(
																										c.stakingToken.price,
																									),
																								)
																								.getValue(),
																						),
																					));
																			case 87:
																				a.next = 92;
																				break;
																			case 89:
																				(a.prev = 89),
																					(a.t11 = a.catch(0)),
																					console.log(a.t11);
																			case 92:
																			case 'end':
																				return a.stop();
																		}
																},
																a,
																null,
																[[0, 89]],
															);
														}),
													);
													return function (b) {
														return a.apply(this, arguments);
													};
												})(),
											);
										})();
									case 2:
									case 'end':
										return a.stop();
								}
						}, a);
					}),
				)).apply(this, arguments);
			}
			function z(a) {
				return A.apply(this, arguments);
			}
			function A() {
				return (A = (0, d.Z)(
					g().mark(function a(b) {
						var c, d, e;
						return g().wrap(
							function (a) {
								for (;;)
									switch ((a.prev = a.next)) {
										case 0:
											return (
												(c = new i.Contract(v, n, r.o.signer)),
												(a.prev = 1),
												(a.next = 4),
												c.claim(b.id, r.o.account, {gasLimit: 2e5})
											);
										case 4:
											return (d = a.sent), (a.next = 7), d.wait();
										case 7:
											(e = a.sent), (a.next = 13);
											break;
										case 10:
											(a.prev = 10), (a.t0 = a.catch(1)), console.log(a.t0);
										case 13:
										case 'end':
											return a.stop();
									}
							},
							a,
							null,
							[[1, 10]],
						);
					}),
				)).apply(this, arguments);
			}
			function B(a, b) {
				return C.apply(this, arguments);
			}
			function C() {
				return (C = (0, d.Z)(
					g().mark(function a(b, c) {
						var d, e, f;
						return g().wrap(function (a) {
							for (;;)
								switch ((a.prev = a.next)) {
									case 0:
										return (
											(d = new i.Contract(v, n, r.o.signer)),
											(a.next = 3),
											d.withdraw(c.id, (0, s.parseEther)(b), {gasLimit: 25e4})
										);
									case 3:
										return (e = a.sent), (a.next = 6), e.wait();
									case 6:
										f = a.sent;
									case 7:
									case 'end':
										return a.stop();
								}
						}, a);
					}),
				)).apply(this, arguments);
			}
			function D(a, b) {
				return E.apply(this, arguments);
			}
			function E() {
				return (E = (0, d.Z)(
					g().mark(function a(b, c) {
						var d, e, f;
						return g().wrap(function (a) {
							for (;;)
								switch ((a.prev = a.next)) {
									case 0:
										return (
											(d = new i.Contract(v, n, r.o.signer)),
											(a.next = 3),
											d.deposit(c.id, (0, s.parseEther)(b), r.o.account, {
												gasLimit: 2e5,
											})
										);
									case 3:
										return (e = a.sent), (a.next = 6), e.wait();
									case 6:
										f = a.sent;
									case 7:
									case 'end':
										return a.stop();
								}
						}, a);
					}),
				)).apply(this, arguments);
			}
			function F() {
				return G.apply(this, arguments);
			}
			function G() {
				return (G = (0, d.Z)(
					g().mark(function a() {
						var b, c, d;
						return g().wrap(function (a) {
							for (;;)
								switch ((a.prev = a.next)) {
									case 0:
										return (
											(b = new i.Contract(v, n, r.o.signer)),
											(a.next = 3),
											b.compoundSmol({gasLimit: 25e4})
										);
									case 3:
										return (c = a.sent), (a.next = 6), c.wait();
									case 6:
										d = a.sent;
									case 7:
									case 'end':
										return a.stop();
								}
						}, a);
					}),
				)).apply(this, arguments);
			}
			function H(a) {
				return I.apply(this, arguments);
			}
			function I() {
				return (I = (0, d.Z)(
					g().mark(function a(b) {
						var c, d, e;
						return g().wrap(function (a) {
							for (;;)
								switch ((a.prev = a.next)) {
									case 0:
										return (
											(c = new i.Contract(w, o, r.o.signer)),
											(a.next = 3),
											c.withdraw((0, s.parseEther)(b))
										);
									case 3:
										return (d = a.sent), (a.next = 6), d.wait();
									case 6:
										e = a.sent;
									case 7:
									case 'end':
										return a.stop();
								}
						}, a);
					}),
				)).apply(this, arguments);
			}
			function J(a) {
				return K.apply(this, arguments);
			}
			function K() {
				return (K = (0, d.Z)(
					g().mark(function a(b) {
						var c, d, e;
						return g().wrap(function (a) {
							for (;;)
								switch ((a.prev = a.next)) {
									case 0:
										return (
											(c = new i.Contract(w, o, r.o.signer)),
											(a.next = 3),
											c.deposit((0, s.parseEther)(b))
										);
									case 3:
										return (d = a.sent), (a.next = 6), d.wait();
									case 6:
										e = a.sent;
									case 7:
									case 'end':
										return a.stop();
								}
						}, a);
					}),
				)).apply(this, arguments);
			}
		},
		68714: function (a, b, c) {
			c.d(b, {
				dE: function () {
					return B;
				},
				Ko: function () {
					return D;
				},
				LV: function () {
					return z;
				},
				XC: function () {
					return w;
				},
			});
			var d,
				e = c(29452),
				f = c(36026),
				g = c(64723),
				h = c.n(g),
				i = c(30365),
				j = c.n(i),
				k = 'https://test.eggs.care/api/dexscreener',
				l = ''.concat(k, '/dex/pairs/ethereum/');
			''.concat(k, '/ping');
			var m =
					((d = (0, e.Z)(
						h().mark(function a(b) {
							var c, d;
							return h().wrap(
								function (a) {
									for (;;)
										switch ((a.prev = a.next)) {
											case 0:
												return (
													(c = ''.concat(l).concat(b)),
													(a.prev = 1),
													(a.next = 4),
													j().get(c)
												);
											case 4:
												return (d = a.sent.data), a.abrupt('return', d);
											case 8:
												(a.prev = 8), (a.t0 = a.catch(1)), console.error(a.t0);
											case 11:
											case 'end':
												return a.stop();
										}
								},
								a,
								null,
								[[1, 8]],
							);
						}),
					)),
					function (a) {
						return d.apply(this, arguments);
					}),
				n = c(89751),
				o = c(35668),
				p = c(24567),
				q = c(65548),
				r = c(40845),
				s = c.n(r),
				t = c(78928),
				u = c(43789),
				v = c(27275),
				w = (0, t.sj)({
					eggs: {
						name: 'eggs',
						label: 'smol protec \uD83E\uDD5A',
						ticker: 'EGGS',
						address: '0x2e516BA5Bf3b7eE47fb99B09eaDb60BDE80a82e0',
						decimals: 18,
					},
					eggsLp: {
						name: 'eggsLp',
						label: 'big protec \uD83E\uDD5A\uD83D\uDD12',
						ticker: 'EGGS/ETH',
						address: '0xc54ba7aabe7164ca2aa092900060fe2ba6eccd8b',
						decimals: 18,
					},
				});
			function x(a, b, c) {
				return y.apply(this, arguments);
			}
			function y() {
				return (y = (0, e.Z)(
					h().mark(function a(b, c, d) {
						var e, g, i, j, k;
						return h().wrap(function (a) {
							for (;;)
								switch ((a.prev = a.next)) {
									case 0:
										return (
											(e = new o.Contract(b.address, n.em, d)),
											(a.t0 = f.Z),
											(a.t1 = Promise),
											(a.next = 5),
											e.balanceOf(c)
										);
									case 5:
										return (a.t2 = a.sent), (a.next = 8), e.allowance(c, v.ww);
									case 8:
										return (a.t3 = a.sent), (a.next = 11), e.allowance(c, v.pH);
									case 11:
										return (
											(a.t4 = a.sent),
											(a.t5 = [a.t2, a.t3, a.t4]),
											(a.next = 15),
											a.t1.all.call(a.t1, a.t5)
										);
									case 15:
										(a.t6 = a.sent),
											(i = (g = (0, a.t0)(a.t6, 3))[0]),
											(j = g[1]),
											(k = g[2]),
											(b.userBalance = (0, q.formatEther)(i)),
											(b.userBalanceFormatted = (0, q.commify)(
												Number((0, q.formatEther)(i)).toFixed(2),
											)),
											(b.userAllowance = Number((0, q.formatEther)(j))),
											(b.userHasAllowance = b.userAllowance > 0),
											(b.userAllowanceFullProtec = Number(
												(0, q.formatEther)(k),
											)),
											(b.userHasAllowanceFullProtec =
												b.userAllowanceFullProtec > 0);
									case 26:
									case 'end':
										return a.stop();
								}
						}, a);
					}),
				)).apply(this, arguments);
			}
			function z(a) {
				return A.apply(this, arguments);
			}
			function A() {
				return (A = (0, e.Z)(
					h().mark(function a(b) {
						var c;
						return h().wrap(function (a) {
							for (;;)
								switch ((a.prev = a.next)) {
									case 0:
										(c = (function () {
											var a = (0, e.Z)(
												h().mark(function a() {
													var c, d, e, g, i, j;
													return h().wrap(
														function (a) {
															for (;;)
																switch ((a.prev = a.next)) {
																	case 0:
																		return (
																			(a.prev = 0),
																			(a.t0 = f.Z),
																			(a.t1 = Promise),
																			(a.next = 5),
																			m(
																				'0xc54ba7aabe7164ca2aa092900060fe2ba6eccd8b',
																			)
																		);
																	case 5:
																		return (
																			(a.t2 = a.sent),
																			(a.t3 = [a.t2]),
																			(a.next = 9),
																			a.t1.all.call(a.t1, a.t3)
																		);
																	case 9:
																		if (
																			((a.t4 = a.sent),
																			!(null ==
																			(d = (c = (0, a.t0)(a.t4, 1))[0])
																				? void 0
																				: d.pair))
																		) {
																			a.next = 23;
																			break;
																		}
																		return (
																			(e = null == d ? void 0 : d.pair),
																			(w.eggs.price = e.priceUsd),
																			(g = new o.Contract(
																				w.eggsLp.address,
																				n.em,
																				b,
																			)),
																			(a.next = 18),
																			g.totalSupply()
																		);
																	case 18:
																		(i = a.sent),
																			(v.zy.eggsTotalLiquidity = (0, q.commify)(
																				e.liquidity.usd,
																			)),
																			(v.zy.eggsFDV = (0, q.commify)(e.fdv)),
																			(v.zy.eggsLpApr =
																				((((365 * e.volume.h24) / 100) * 0.3) /
																					e.liquidity.usd) *
																				100),
																			(w.eggsLp.price = new (s())(
																				e.liquidity.usd,
																			)
																				.divide(
																					new (s())((0, q.formatEther)(i)),
																					10,
																				)
																				.getValue());
																	case 23:
																		(j = u.o.account) &&
																			(x(w.eggs, j, b), x(w.eggsLp, j, b)),
																			(a.next = 30);
																		break;
																	case 27:
																		(a.prev = 27),
																			(a.t5 = a.catch(0)),
																			console.log(a.t5);
																	case 30:
																	case 'end':
																		return a.stop();
																}
														},
														a,
														null,
														[[0, 27]],
													);
												}),
											);
											return function () {
												return a.apply(this, arguments);
											};
										})())();
									case 2:
									case 'end':
										return a.stop();
								}
						}, a);
					}),
				)).apply(this, arguments);
			}
			function B(a) {
				return C.apply(this, arguments);
			}
			function C() {
				return (C = (0, e.Z)(
					h().mark(function a(b) {
						var c, d, e;
						return h().wrap(function (a) {
							for (;;)
								switch ((a.prev = a.next)) {
									case 0:
										return (
											(c = new o.Contract(
												b.stakingToken.address,
												n.em,
												u.o.signer,
											)),
											(a.next = 3),
											c.approve(v.ww, p.Bz)
										);
									case 3:
										return (d = a.sent), (a.next = 6), d.wait();
									case 6:
										e = a.sent;
									case 7:
									case 'end':
										return a.stop();
								}
						}, a);
					}),
				)).apply(this, arguments);
			}
			function D(a) {
				return E.apply(this, arguments);
			}
			function E() {
				return (E = (0, e.Z)(
					h().mark(function a(b) {
						var c, d, e;
						return h().wrap(function (a) {
							for (;;)
								switch ((a.prev = a.next)) {
									case 0:
										return (
											(c = new o.Contract(
												b.stakingToken.address,
												n.em,
												u.o.signer,
											)),
											(a.next = 3),
											c.approve(v.pH, p.Bz)
										);
									case 3:
										return (d = a.sent), (a.next = 6), d.wait();
									case 6:
										e = a.sent;
									case 7:
									case 'end':
										return a.stop();
								}
						}, a);
					}),
				)).apply(this, arguments);
			}
		},
		5926: function (a, b, c) {
			c.d(b, {
				W: function () {
					return d;
				},
			});
			var d = function (a) {
				var b =
						arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2,
					c =
						arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 2;
				return a.toLocaleString('en-us', {
					minimumFractionDigits: b,
					maximumFractionDigits: c,
				});
			};
		},
	},
]);
