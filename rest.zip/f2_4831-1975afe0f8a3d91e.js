// 4831-1975afe0f8a3d91e.js
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
	[4831],
	{
		16439: function (a, b, c) {
			'use strict';
			c.d(b, {
				Z: function () {
					return g;
				},
			});
			var d = c(11527),
				e = c(4017),
				f = c(5926);
			function g(a) {
				var b = a.amount,
					c = (0, e.useSpring)({
						from: {number: 0},
						number: b,
						config: e.config.molasses,
					}).number;
				return b
					? (0, d.jsx)(e.animated.span, {
							children: c.to(function (a) {
								return (0, f.W)(a, 3, 3);
							}),
					  })
					: (0, d.jsx)('span', {children: '...'});
			}
		},
		38503: function (a, b, c) {
			'use strict';
			c.d(b, {
				Z: function () {
					return l;
				},
			});
			var d = c(29452),
				e = c(64723),
				f = c.n(e),
				g = c(11527),
				h = c(50959),
				i = function (a) {
					return a.toString().padStart(2, '0');
				},
				j = function (a) {
					var b = new Date().getTime(),
						c = new Date(1e3 * a),
						d = Math.floor((c.getTime() - b) / 1e3),
						e = Math.floor(d / 60),
						f = Math.floor(e / 60),
						g = Math.floor(f / 24);
					return ((f -= 24 * g),
					(e = e - 1440 * g - 60 * f),
					(d = d - 86400 * g - 3600 * f - 60 * e),
					g < 0)
						? 'Ended - Refresh!'
						: ''
								.concat(i(g), ':')
								.concat(i(f), ':')
								.concat(i(e), ':')
								.concat(i(d));
				},
				k = function (a) {
					var b = a.timeInput,
						c = (0, h.useState)('...'),
						e = c[0],
						i = c[1];
					return (
						(0, h.useEffect)(
							function () {
								var a = setInterval(
									(0, d.Z)(
										f().mark(function a() {
											var c;
											return f().wrap(function (a) {
												for (;;)
													switch ((a.prev = a.next)) {
														case 0:
															(c = j(b)), i(c);
														case 2:
														case 'end':
															return a.stop();
													}
											}, a);
										}),
									),
								);
								return function () {
									return clearInterval(a);
								};
							},
							[b],
						),
						(0, g.jsx)('span', {children: e}, e)
					);
				},
				l = k;
		},
		94831: function (a, b, c) {
			'use strict';
			c.r(b);
			var d = c(11527),
				e = c(50959),
				f = c(19803),
				g = c.n(f),
				h = c(27275),
				i = c(16439),
				j = c(7634),
				k = c.n(j),
				l = c(68714),
				m = c(96281),
				n = c(38503),
				o = function (a) {
					var b = a.farm,
						c = (0, e.useState)('stake'),
						f = c[0],
						j = c[1],
						o = (0, e.useState)(''),
						p = o[0],
						q = o[1],
						r = (0, e.useState)(''),
						s = r[0],
						t = r[1],
						u = (0, e.useState)(''),
						v = u[0],
						w = u[1],
						x = (0, e.useState)(''),
						y = x[0],
						z = x[1];
					return b
						? (0, d.jsx)(d.Fragment, {
								children: (0, d.jsxs)('div', {
									children: [
										(0, d.jsx)('div', {
											style: {display: 'flex', justifyContent: 'center'},
											children: (0, d.jsxs)('h1', {
												className: k().title,
												style: {marginBottom: '1.5rem'},
												children: [
													b.label,
													' ',
													1 === b.id &&
														(0, d.jsx)('img', {
															src: '/assets/smolting.png',
															style: {marginBottom: 10, height: 50},
														}),
												],
											}),
										}),
										(0, d.jsxs)('div', {
											className: k().container,
											children: [
												'fullprotec' === b.type
													? (0, d.jsx)('div', {
															children: (0, d.jsxs)('div', {
																className: k().statsFullProtec,
																children: [
																	(0, d.jsxs)('div', {
																		children: [
																			(0, d.jsx)('p', {
																				children: 'protec amount',
																			}),
																			(0, d.jsx)(m.ZP, {
																				content:
																					(
																						(Number(b.userStakedAmountUsd) /
																							Number(b.tvl)) *
																						100
																					).toFixed(2) + '% of total staked',
																				offset: 4,
																				shadow: !0,
																				hideArrow: !0,
																				children: (0, d.jsxs)('p', {
																					className: k().tooltip,
																					children: [
																						'$',
																						b.userStakedAmountUsdFormatted,
																					],
																				}),
																			}),
																		],
																	}),
																	(0, d.jsxs)('div', {
																		children: [
																			(0, d.jsx)('p', {children: 'TVL'}),
																			(0, d.jsxs)('p', {
																				children: ['$', b.tvlFormatted],
																			}),
																		],
																	}),
																],
															}),
													  })
													: (0, d.jsxs)('div', {
															children: [
																(0, d.jsxs)('div', {
																	className: k().stats,
																	children: [
																		(0, d.jsxs)('div', {
																			children: [
																				(0, d.jsx)('p', {
																					children: 'protec amount',
																				}),
																				(0, d.jsx)(m.ZP, {
																					content:
																						(
																							(Number(b.userStakedAmountUsd) /
																								Number(b.tvl)) *
																							100
																						).toFixed(2) + '% of total staked',
																					offset: 4,
																					shadow: !0,
																					hideArrow: !0,
																					children: (0, d.jsxs)('p', {
																						className: k().tooltip,
																						children: [
																							'$',
																							b.userStakedAmountUsdFormatted,
																						],
																					}),
																				}),
																			],
																		}),
																		(0, d.jsxs)('div', {
																			children: [
																				(0, d.jsx)('p', {
																					children: 'eggs accumulatooor',
																				}),
																				(0, d.jsx)(m.ZP, {
																					content: b.userEarnedUsd
																						? '$'.concat(b.userEarnedUsd)
																						: '',
																					offset: 4,
																					shadow: !0,
																					hideArrow: !0,
																					children: (0, d.jsxs)('p', {
																						className: k().tooltip,
																						children: [
																							(0, d.jsx)(i.Z, {
																								amount: b.userEarned,
																							}),
																							' ',
																						],
																					}),
																				}),
																			],
																		}),
																		(0, d.jsxs)('div', {
																			children: [
																				(0, d.jsx)('p', {
																					children: 'eggspected APR',
																				}),
																				b.finished
																					? (0, d.jsx)('p', {children: '...'})
																					: (0, d.jsxs)('p', {
																							children: [b.aprFormatted, '%'],
																					  }),
																			],
																		}),
																		(0, d.jsxs)('div', {
																			children: [
																				(0, d.jsx)('p', {children: 'TVL'}),
																				(0, d.jsxs)('p', {
																					children: ['$', b.tvlFormatted],
																				}),
																			],
																		}),
																	],
																}),
																(0, d.jsxs)('div', {
																	style: {
																		display: 'flex',
																		marginTop: '1rem',
																		gap: '0.5rem',
																	},
																	children: [
																		(0, d.jsx)('button', {
																			className: g()('button', k().button),
																			onClick: function () {
																				return (0, h.YY)(b);
																			},
																			disabled: !b.userEarned,
																			children: 'claim eggs',
																		}),
																		1 === b.id &&
																			(0, d.jsx)('button', {
																				className: g()('button', k().button),
																				onClick: function () {
																					return (0, h.Dr)();
																				},
																				disabled: !b.userEarned,
																				children: 'Compound',
																			}),
																	],
																}),
															],
													  }),
												(0, d.jsxs)('div', {
													className: k().actions,
													children: [
														(0, d.jsxs)('div', {
															children: [
																(0, d.jsx)('button', {
																	className: g()(
																		k().tablink,
																		'stake' === f && k().active,
																	),
																	onClick: function () {
																		return j('stake');
																	},
																	style: {marginRight: '1rem'},
																	children: 'deposit',
																}),
																(0, d.jsx)('button', {
																	className: g()(
																		k().tablink,
																		'unstake' === f && k().active,
																	),
																	onClick: function () {
																		return j('unstake');
																	},
																	children: 'withdraw',
																}),
															],
														}),
														'stake' === f &&
															(0, d.jsxs)(d.Fragment, {
																children: [
																	(0, d.jsxs)('div', {
																		className: k().balance,
																		children: [
																			(0, d.jsx)('div', {
																				children: 'token balance',
																			}),
																			(0, d.jsx)('div', {
																				children:
																					b.stakingToken.userBalanceFormatted,
																			}),
																		],
																	}),
																	(0, d.jsxs)('div', {
																		style: {position: 'relative'},
																		children: [
																			(0, d.jsx)('input', {
																				className: k().input,
																				type: 'number',
																				placeholder: '0.00',
																				onChange: function (a) {
																					q(a.target.value), t(a.target.value);
																				},
																				value: s,
																			}),
																			(0, d.jsx)('button', {
																				className: g()('button', k().maxbutton),
																				onClick: function () {
																					q(b.stakingToken.userBalance),
																						t(b.stakingToken.userBalance);
																				},
																				children: 'max',
																			}),
																		],
																	}),
																	(0, d.jsx)('div', {
																		style: {textAlign: 'center'},
																		children: (0, d.jsx)('a', {
																			href:
																				b.stakingToken.address ===
																				l.XC.eggs.address
																					? 'https://app.uniswap.org/#/swap?inputCurrency=ETH&outputCurrency=0x2e516ba5bf3b7ee47fb99b09eadb60bde80a82e0'
																					: b.lpUrl,
																			target: '_blank',
																			rel: 'noreferrer',
																			children:
																				b.stakingToken.address ===
																				l.XC.eggs.address
																					? 'get EGGS here ↗️'
																					: 'provide LP here ↗️',
																		}),
																	}),
																	(
																		'fullprotec' === b.type
																			? b.stakingToken
																					.userHasAllowanceFullProtec
																			: b.stakingToken.userHasAllowance
																	)
																		? (0, d.jsx)('button', {
																				className: g()('button', k().button),
																				onClick: function () {
																					return 'fullprotec' === b.type
																						? (0, h._6)(p)
																						: (0, h.LK)(p, b);
																				},
																				children: 'Deposit',
																		  })
																		: (0, d.jsx)('button', {
																				className: g()('button', k().button),
																				onClick: function () {
																					return 'fullprotec' === b.type
																						? (0, l.Ko)(b)
																						: (0, l.dE)(b);
																				},
																				children: 'approve',
																		  }),
																],
															}),
														'unstake' === f &&
															(0, d.jsxs)(d.Fragment, {
																children: [
																	(0, d.jsxs)('div', {
																		className: k().balance,
																		children: [
																			(0, d.jsx)('div', {
																				children:
																					b.lpInfo.address === l.XC.eggs.address
																						? 'fullprotec' === b.type
																							? 'protected amount'
																							: 'protected shares'
																						: 'protected amount',
																			}),
																			(0, d.jsx)('div', {
																				children:
																					b.userStakedAmountFormatted || '0',
																			}),
																		],
																	}),
																	(0, d.jsxs)('div', {
																		style: {position: 'relative'},
																		children: [
																			(0, d.jsx)('input', {
																				className: k().input,
																				type: 'number',
																				placeholder: '0.00',
																				onChange: function (a) {
																					w(a.target.value), z(a.target.value);
																				},
																				value: y,
																			}),
																			(0, d.jsx)('button', {
																				className: g()('button', k().maxbutton),
																				onClick: function () {
																					w(b.userStakedAmount),
																						z(b.userStakedAmount);
																				},
																				children: 'max',
																			}),
																		],
																	}),
																	(0, d.jsx)('div', {
																		style: {textAlign: 'center'},
																	}),
																	(
																		'fullprotec' === b.type
																			? b.stakingToken
																					.userHasAllowanceFullProtec
																			: b.stakingToken.userHasAllowance
																	)
																		? (0, d.jsx)('button', {
																				className: g()('button', k().button),
																				onClick: function () {
																					return 'fullprotec' === b.type
																						? (0, h.XW)(v)
																						: (0, h.HV)(v, b);
																				},
																				disabled: b.withdrawLocked,
																				children: b.withdrawLocked
																					? (0, d.jsxs)(d.Fragment, {
																							children: [
																								'lock ends in',
																								' ',
																								(0, d.jsx)('span', {
																									style: {
																										marginLeft: '0.25rem',
																									},
																									children: (0, d.jsx)(n.Z, {
																										timeInput:
																											b.lockEndedTimestamp,
																									}),
																								}),
																							],
																					  })
																					: 'withdraw',
																		  })
																		: (0, d.jsx)('button', {
																				className: g()('button', k().button),
																				onClick: function () {
																					return 'fullprotec' === b.type
																						? (0, l.Ko)(b)
																						: (0, l.dE)(b);
																				},
																				children: 'approve',
																		  }),
																],
															}),
													],
												}),
											],
										}),
									],
								}),
						  })
						: null;
				};
			b.default = o;
		},
		7634: function (a) {
			a.exports = {
				container: 'Actions_container__pDkJB',
				stats: 'Actions_stats__JAAdt',
				statsFullProtec: 'Actions_statsFullProtec__7lOBx',
				actions: 'Actions_actions__M_7BJ',
				active: 'Actions_active__TwWf0',
				info: 'Actions_info__ayc1h',
				list: 'Actions_list__oJHhR',
				item: 'Actions_item__lw1Td',
				category: 'Actions_category__NPO_X',
				content: 'Actions_content__coZBm',
				btns: 'Actions_btns__kMgri',
				button: 'Actions_button__RGIgK',
				tablink: 'Actions_tablink__2U6X2',
				input: 'Actions_input__r3b_T',
				maxbutton: 'Actions_maxbutton__B6ax9',
				balance: 'Actions_balance__YbiOW',
				tooltip: 'Actions_tooltip__lDk4T',
				title: 'Actions_title__k_HaF',
			};
		},
	},
]);
