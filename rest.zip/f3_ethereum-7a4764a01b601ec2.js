// ethereum-7a4764a01b601ec2.js
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
	[8110],
	{
		93907: function (a, b, c) {
			(window.__NEXT_P = window.__NEXT_P || []).push([
				'/ethereum',
				function () {
					return c(29948);
				},
			]);
		},
		29948: function (a, b, c) {
			'use strict';
			c.r(b);
			var d = c(11527),
				e = c(97749),
				f = c.n(e),
				g = c(42517),
				h = function () {
					return (0, d.jsxs)(d.Fragment, {
						children: [
							(0, d.jsxs)(f(), {
								children: [
									(0, d.jsx)('title', {children: 'Eggs'}),
									(0, d.jsx)('meta', {name: 'description', content: 'Eggs'}),
									(0, d.jsx)('link', {rel: 'icon', href: '/favicon.ico'}),
								],
							}),
							(0, d.jsx)(g.default, {}),
						],
					});
				};
			b.default = h;
		},
		21606: function (a, b, c) {
			'use strict';
			c.r(b),
				c.d(b, {
					default: function () {
						return l;
					},
				});
			var d = c(11527),
				e = c(19803),
				f = c.n(e),
				g = c(6930),
				h = c(27275),
				i = c(22145),
				j = c.n(i),
				k = c(96281);
			function l() {
				var a = (0, g.RK)(h.zy);
				return (0, d.jsxs)('div', {
					children: [
						(0, d.jsx)('div', {
							style: {display: 'flex', justifyContent: 'center'},
							children: (0, d.jsx)('h1', {
								className: f()('h2', j().title),
								style: {marginBottom: '1.5rem'},
								children: 'Eggs Stats \uD83E\uDD5A\uD83D\uDCCA',
							}),
						}),
						(0, d.jsx)('div', {
							className: j().container,
							children: (0, d.jsx)('div', {
								children: (0, d.jsxs)('div', {
									className: j().stats,
									children: [
										(0, d.jsxs)('div', {
											children: [
												(0, d.jsx)('p', {children: 'Total TVL'}),
												(0, d.jsxs)('p', {
													className: j().tooltip,
													children: ['$', a.totalTvl],
												}),
											],
										}),
										(0, d.jsxs)('div', {
											children: [
												(0, d.jsx)('p', {
													children: 'Marketcap (Fully Diluted)',
												}),
												(0, d.jsxs)('p', {
													className: j().tooltip,
													children: ['$', a.eggsFDV],
												}),
											],
										}),
										(0, d.jsxs)('div', {
											children: [
												(0, d.jsx)('p', {children: 'Total Liquidity'}),
												(0, d.jsxs)('p', {
													className: j().tooltip,
													children: ['$', a.eggsTotalLiquidity],
												}),
											],
										}),
										(0, d.jsxs)('div', {
											children: [
												(0, d.jsx)('p', {children: 'Total Supply'}),
												(0, d.jsxs)('p', {
													className: j().tooltip,
													children: [a.eggsTotalSupplyFormatted, ' EGGS'],
												}),
											],
										}),
										(0, d.jsxs)('div', {
											children: [
												(0, d.jsx)('p', {children: 'Supply in Vaults'}),
												(0, d.jsx)(k.ZP, {
													content:
														((a.eggsInFarm / a.eggsTotalSupply) * 100).toFixed(
															2,
														) + '% of total supply',
													offset: 4,
													shadow: !0,
													hideArrow: !0,
													children: (0, d.jsxs)('p', {
														className: j().tooltip,
														children: [a.eggsInFarmFormatted, ' EGGS'],
													}),
												}),
											],
										}),
										(0, d.jsxs)('div', {
											children: [
												(0, d.jsx)('p', {children: 'Circulating supply'}),
												(0, d.jsx)(k.ZP, {
													content:
														(
															(a.eggsCircSupply / a.eggsTotalSupply) *
															100
														).toFixed(2) + '% of total supply',
													offset: 4,
													shadow: !0,
													hideArrow: !0,
													children: (0, d.jsxs)('p', {
														className: j().tooltip,
														children: [a.eggsCircSupplyFormatted, ' EGGS'],
													}),
												}),
											],
										}),
									],
								}),
							}),
						}),
					],
				});
			}
		},
		90571: function (a, b, c) {
			'use strict';
			c.r(b);
			var d = c(11527),
				e = c(19803),
				f = c.n(e),
				g = c(6930),
				h = c(27275),
				i = c(14080),
				j = c.n(i),
				k = c(94831),
				l = c(68714),
				m = c(41413),
				n = c(21606),
				o = function (a) {
					a.block;
					var b = (0, g.RK)(h.JP);
					return (
						(0, g.RK)(h.zy),
						(0, d.jsxs)(d.Fragment, {
							children: [
								(0, d.jsx)('div', {
									style: {
										position: 'fixed',
										top: '1rem',
										right: '1rem',
										zIndex: 100,
									},
									children: (0, d.jsx)(m.NL, {
										showBalance: {smallScreen: !1, largeScreen: !1},
									}),
								}),
								(0, d.jsx)('div', {
									className: f()('section', j().section),
									children: (0, d.jsxs)('div', {
										className: f()('container', j().container),
										children: [
											(0, d.jsx)('h1', {
												className: f()('h1', j().title),
												children: 'Eggs \uD83E\uDD5A',
											}),
											(0, d.jsxs)('div', {
												className: j().info,
												children: [
													(0, d.jsx)('div', {
														className: j().image,
														children: (0, d.jsx)('img', {
															src: '/assets/egg.jpg',
															className: j().image,
														}),
													}),
													(0, d.jsxs)('div', {
														className: j().line,
														children: [
															(0, d.jsx)('p', {
																children:
																	'The notorious Egg Cartel are running wild globally and causing a unprecedented egg shortage! The egg supply decreases rapidly with 0.001% per block... The only way to protec your eggs is to put them in the vault.',
															}),
															(0, d.jsx)('p', {
																children:
																	"There are three types of vaults. Full protec vault will protect your precious eggs FULLY and won't be affected by debase. Full protec vault has a locking period of 7 days. The other two vaults only protect your EGGS partially in the form of rewards. The rewards are 10 million EGGS per block. Big protec vault earns you 9/10 of the rewards by staking EGGS/ETH LP on Uniswap V2. The smol protec vault earns you only 1/10 of the rewards. Both of these vaults only have a locking period of 24 hours.",
															}),
															(0, d.jsxs)('div', {
																className: j().buttonLinkSection,
																children: [
																	(0, d.jsx)('a', {
																		className: f()('button button-stroke'),
																		style: {textAlign: 'center'},
																		href: 'https://t.me/eggsportal',
																		target: '_blank',
																		rel: 'noreferrer',
																		children: 'Telegram',
																	}),
																	(0, d.jsx)('a', {
																		className: f()('button button-stroke'),
																		style: {textAlign: 'center'},
																		href: 'https://twitter.com/EggsCare',
																		target: '_blank',
																		rel: 'noreferrer',
																		children: 'Twitter',
																	}),
																	(0, d.jsx)('a', {
																		className: f()('button button-stroke'),
																		style: {textAlign: 'center'},
																		href: 'https://docs.eggs.care',
																		target: '_blank',
																		rel: 'noreferrer',
																		children: 'Docs',
																	}),
																	(0, d.jsx)('a', {
																		className: f()('button button-stroke'),
																		style: {
																			marginBottom: '1rem',
																			textAlign: 'center',
																		},
																		href: 'https://www.dextools.io/app/en/ether/pair-explorer/0xc54ba7aabe7164ca2aa092900060fe2ba6eccd8b',
																		target: '_blank',
																		rel: 'noreferrer',
																		children: 'Chart',
																	}),
																],
															}),
															(0, d.jsx)('a', {
																href: 'https://app.uniswap.com/#/swap?outputCurrency='.concat(
																	l.XC.eggs.address,
																),
																target: '_blank',
																rel: 'noreferrer',
																children: (0, d.jsx)('button', {
																	className: f()('button'),
																	style: {width: '100%'},
																	children: 'Get EGGS',
																}),
															}),
														],
													}),
												],
											}),
											(0, d.jsx)(n.default, {}),
											b.map(function (a, b) {
												return (0, d.jsx)(k.default, {farm: a}, a.id);
											}),
										],
									}),
								}),
							],
						})
					);
				};
			b.default = o;
		},
		42517: function (a, b, c) {
			'use strict';
			c.r(b);
			var d = c(29452),
				e = c(64723),
				f = c.n(e),
				g = c(11527),
				h = c(43789),
				i = c(27275),
				j = c(68714),
				k = c(50959),
				l = c(33599),
				m = c(90571),
				n = c(11903),
				o = c.n(n),
				p = function () {
					h.o.provider = (0, l.yL)();
					var a = (0, l.mx)().data,
						b = (0, l.mA)().address,
						c = (0, l.Ov)({watch: !0}),
						e = c.data;
					return (
						(h.o.account = b),
						(h.o.signer = a),
						(0, k.useEffect)(
							function () {
								function a() {
									return (a = (0, d.Z)(
										f().mark(function a() {
											return f().wrap(function (a) {
												for (;;)
													switch ((a.prev = a.next)) {
														case 0:
															return (a.next = 2), (0, j.LV)(h.o.provider);
														case 2:
															return (a.next = 4), (0, i.W)(h.o.provider);
														case 4:
														case 'end':
															return a.stop();
													}
											}, a);
										}),
									)).apply(this, arguments);
								}
								!(function () {
									return a.apply(this, arguments);
								})();
							},
							[b, e],
						),
						(0, g.jsx)('div', {
							className: o().farms,
							children: (0, g.jsx)(m.default, {block: e}),
						})
					);
				};
			b.default = p;
		},
		11903: function (a) {
			a.exports = {farms: 'Farms_farms__atoN_'};
		},
		14080: function (a) {
			a.exports = {
				section: 'Farms_section__PIcZ5',
				info: 'Farms_info__NToXS',
				line: 'Farms_line__ekIql',
				button: 'Farms_button__1L4zx',
				image: 'Farms_image__GTksV',
				nav: 'Farms_nav__CIdve',
				dropdown: 'Farms_dropdown__3_bxZ',
				link: 'Farms_link__lkE0t',
				active: 'Farms_active__V88VB',
				table: 'Farms_table__oAqxW',
				row: 'Farms_row__jBGrm',
				col: 'Farms_col__Vys_Q',
				item: 'Farms_item__Oqddf',
				icon: 'Farms_icon__kOMgU',
				currency: 'Farms_currency__KJ_mj',
				positive: 'Farms_positive__bLRcl',
				negative: 'Farms_negative__75nEk',
				chart: 'Farms_chart__R_0e8',
				title: 'Farms_title__d26_b',
				buttonLinkSection: 'Farms_buttonLinkSection__wnKTj',
			};
		},
		22145: function (a) {
			a.exports = {
				container: 'Stats_container__B7fa8',
				stats: 'Stats_stats__ZwCGO',
				actions: 'Stats_actions__WYMiX',
				active: 'Stats_active__Z2ztj',
				info: 'Stats_info__uHX3H',
				list: 'Stats_list___R1wx',
				item: 'Stats_item__wai3S',
				category: 'Stats_category__G194T',
				content: 'Stats_content__UF9FL',
				btns: 'Stats_btns__Ckg_r',
				button: 'Stats_button__hxQSI',
				tablink: 'Stats_tablink___4zGe',
				input: 'Stats_input__Q8xwc',
				maxbutton: 'Stats_maxbutton__isuTc',
				balance: 'Stats_balance__LuJ8H',
				tooltip: 'Stats_tooltip__Za9DT',
				title: 'Stats_title__9Sy8h',
			};
		},
		6930: function (a, b, c) {
			'use strict';
			c.d(b, {
				RK: function () {
					return j;
				},
			});
			var d = c(50959),
				e = c(16386),
				f = c(4322),
				g = c(78928);
			let {useSyncExternalStore: h} = f,
				i = (a, b) => {
					let c = (0, d.useRef)();
					(0, d.useEffect)(() => {
						c.current = (0, e.h8)(a, b);
					}),
						(0, d.useDebugValue)(c.current);
				};
			function j(a, b) {
				let c = null == b ? void 0 : b.sync,
					f = (0, d.useRef)(),
					j = (0, d.useRef)(),
					k = !0,
					l = h(
						(0, d.useCallback)(
							b => {
								let d = (0, g.Ld)(a, b, c);
								return b(), d;
							},
							[a, c],
						),
						() => {
							let b = (0, g.CO)(a);
							try {
								if (
									!k &&
									f.current &&
									j.current &&
									!(0, e.ln)(f.current, b, j.current, new WeakMap())
								)
									return f.current;
							} catch (c) {}
							return b;
						},
						() => (0, g.CO)(a),
					);
				k = !1;
				let m = new WeakMap();
				(0, d.useEffect)(() => {
					(f.current = l), (j.current = m);
				}),
					i(l, m);
				let n = (0, d.useMemo)(() => new WeakMap(), []);
				return (0, e.DM)(l, m, n);
			}
		},
	},
	function (a) {
		a.O(0, [5872, 9487, 4017, 332, 4831, 9774, 2888, 179], function () {
			var b;
			return a((a.s = 93907));
		}),
			(_N_E = a.O());
	},
]);
